#!/usr/bin/env bash
set -e
echo "==================================================="
echo "Building MetaTrader 5 Offline Capacitor Android APK"
echo "==================================================="
npm install
if [ ! -d "android" ]; then
    npx cap add android
fi
node apply-android-customizations.js
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
echo ""
echo "==================================================="
echo "DONE! Your APK is located at:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
echo "==================================================="
