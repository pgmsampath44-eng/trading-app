@echo off
echo ===================================================
echo Building MetaTrader 5 Offline Capacitor Android APK
echo ===================================================
call npm install
if not exist "android" (
    call npx cap add android
)
call node apply-android-customizations.js
call npx cap sync android
cd android
call gradlew.bat assembleDebug
echo.
echo ===================================================
echo DONE! Your APK is located at:
echo android\app\build\outputs\apk\debug\app-debug.apk
echo ===================================================
pause
