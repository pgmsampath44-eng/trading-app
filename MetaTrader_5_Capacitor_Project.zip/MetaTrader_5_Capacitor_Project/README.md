# MetaTrader 5 Offline — Capacitor Android APK Project

This package contains your exact `chart (23).html` file inside a pre-configured Capacitor 6 Android project with your custom MetaTrader 5 home-screen icons pre-generated for all Android screen densities.

## Option 1: Build APK in the Cloud for Free (No Android Studio Needed!)
If you don't want to install the heavy Android SDK / Android Studio on your computer:
1. Create a free repository on GitHub (https://github.com/new).
2. Extract this ZIP and upload all files (including the `.github` folder) to your repository.
3. Click the **Actions** tab in your GitHub repository.
4. The **Build MetaTrader 5 Android APK** workflow will run automatically and finish in ~2 minutes.
5. Click the completed workflow run and download **MetaTrader-5-Offline-APK** (`app-debug.apk`), then install it directly on your Android phone!

## Option 2: Build Locally on Your PC (Windows / Linux / Mac)
Prerequisites: Node.js (v18+) and Android Studio (with Android SDK & Java 17).
- **Windows:** Double-click `build-apk.bat`
- **Linux / macOS:** Run `chmod +x build-apk.sh && ./build-apk.sh`

Your installable APK will be output to:
`android/app/build/outputs/apk/debug/app-debug.apk`
