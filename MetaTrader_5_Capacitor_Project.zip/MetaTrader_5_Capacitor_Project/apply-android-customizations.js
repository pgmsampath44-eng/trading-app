const fs = require('fs');
const path = require('path');

const resDir = path.join(__dirname, 'android', 'app', 'src', 'main', 'res');
const prebuiltResDir = path.join(__dirname, 'android-custom-res');

function copyRecursiveSync(src, dest) {
  if (!fs.existsSync(src)) return;
  const stats = fs.statSync(src);
  if (stats.isDirectory()) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    fs.readdirSync(src).forEach(child => {
      copyRecursiveSync(path.join(src, child), path.join(dest, child));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
}

// 1. Copy all pre-sized MT5 launcher icons into android/app/src/main/res
if (fs.existsSync(resDir)) {
  copyRecursiveSync(prebuiltResDir, resDir);
  console.log('Copied custom MT5 launcher icons into Android res/ directory.');
}

// 2. Remove default adaptive vector background/foreground XMLs if they conflict
const anydpiV26 = path.join(resDir, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpiV26)) {
  const icXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>`;
  fs.writeFileSync(path.join(anydpiV26, 'ic_launcher.xml'), icXml);
  fs.writeFileSync(path.join(anydpiV26, 'ic_launcher_round.xml'), icXml);
}

// 3. Set ic_launcher_background color to #0868C8 (MT5 Blue) and status/navigation bar to #000000
const valuesDir = path.join(resDir, 'values');
if (fs.existsSync(valuesDir)) {
  const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#000000</color>
    <color name="colorPrimaryDark">#000000</color>
    <color name="colorAccent">#3f8cff</color>
    <color name="ic_launcher_background">#0868C8</color>
</resources>`;
  fs.writeFileSync(path.join(valuesDir, 'ic_launcher_background.xml'), colorsXml);
}

// 4. Lock Portrait Orientation & Dark Fullscreen Theme in AndroidManifest.xml
const manifestPath = path.join(__dirname, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android:screenOrientation')) {
    manifest = manifest.replace(
      'android:name=".MainActivity"',
      'android:name=".MainActivity"\n            android:screenOrientation="portrait"'
    );
    fs.writeFileSync(manifestPath, manifest, 'utf8');
    console.log('Locked portrait orientation in AndroidManifest.xml.');
  }
}
